import { type CSSProperties, type ChangeEvent, type ReactNode, useEffect, useMemo, useState } from "react";
import { cn } from "./utils/cn";

type TabId =
  | "overview"
  | "flows"
  | "connectors"
  | "notes"
  | "vicogate"
  | "vicoflow"
  | "news"
  | "settings"
  | "legal";

type BrandTheme = "electric" | "gold";
type LinkShape = "pill" | "rounded" | "tile";
type FlowKind = "trigger" | "action" | "ai" | "condition" | "output";
type FlowStatus = "draft" | "sandbox" | "live";
type ArtifactType = "html" | "js" | "json" | "react";
type SourceLang = "en" | "es";

type FlowStep = {
  id: string;
  kind: FlowKind;
  title: string;
  connector: string;
  description: string;
  color: string;
};

type FlowVersion = {
  version: number;
  label: string;
  at: string;
};

type Flow = {
  id: string;
  name: string;
  category: string;
  description: string;
  status: FlowStatus;
  version: number;
  versions: FlowVersion[];
  steps: FlowStep[];
};

type Folder = {
  id: string;
  name: string;
  color: string;
};

type Note = {
  id: string;
  folderId: string;
  title: string;
  content: string;
  updatedAt: string;
};

type QuickLink = {
  id: string;
  label: string;
  url: string;
  color: string;
  shape: LinkShape;
};

type Widget = {
  id: string;
  title: string;
  type: "html" | "markdown" | "json";
  content: string;
  createdAt: string;
};

type GateApp = {
  id: string;
  name: string;
  url?: string;
  srcDoc?: string;
  type: "url" | "html" | "js" | "json" | "zip";
  description: string;
  adminOnly?: boolean;
  createdAt: string;
};

type GateMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
};

type Artifact = {
  id: string;
  title: string;
  type: ArtifactType;
  prompt: string;
  code: string;
  createdAt: string;
};

type NewsSource = {
  id: string;
  name: string;
  lang: SourceLang;
  category: string;
  url: string;
  headlines: string[];
  dynamic?: boolean;
};

type Settings = {
  darkMode: boolean;
  brandTheme: BrandTheme;
  integratedAI: boolean;
  animationSpeed: number;
  customAccent: string;
  offlineFirst: boolean;
  scriptEditorEnabled: boolean;
  rssLanguage: "en" | "es" | "both";
  rssEnabled: boolean;
  rssView: "ticker" | "cards";
  tickerSpeed: number;
  navbarShortcuts: TabId[];
  sandboxMode: boolean;
  soundEnabled: boolean;
  securityProfile: "balanced" | "strict" | "enterprise";
  advancedHashes: boolean;
};

type PomodoroState = {
  focusMinutes: number;
  breakMinutes: number;
  remaining: number;
  running: boolean;
  mode: "focus" | "break";
};

type AdminKeyPayload = {
  label: string;
  format: string;
  algorithm: string;
  hashEngine: string;
  hash: string;
  createdAt: string;
  permissions: string[];
};

const ADMIN_SECRET = "ANDRESXPOP1985";

const TAB_ITEMS: Array<{ id: TabId; label: string; icon: string }> = [
  { id: "overview", label: "Dashboard", icon: "◈" },
  { id: "flows", label: "Flows", icon: "⇄" },
  { id: "connectors", label: "Conectores", icon: "◎" },
  { id: "notes", label: "Notas", icon: "✎" },
  { id: "vicogate", label: "VICOgate", icon: "▣" },
  { id: "vicoflow", label: "VICO Flow", icon: "⌘" },
  { id: "news", label: "RSS IA", icon: "☰" },
  { id: "settings", label: "Config", icon: "⚙" },
  { id: "legal", label: "Legal", icon: "§" },
];

const CONNECTORS = [
  ["API REST", "Universal", "Endpoints, tokens y mapeo JSON"],
  ["Webhooks", "Universal", "Recepción y envío en tiempo real"],
  ["Email (SMTP/IMAP)", "Mensajería", "Bandejas, alertas y archivos"],
  ["Google Drive", "Workspace", "Archivos, triggers y copias"],
  ["Google Docs", "Workspace", "Documentos y plantillas"],
  ["Google Sheets", "Workspace", "Tablas, celdas y métricas"],
  ["Google Calendar", "Workspace", "Eventos, recordatorios y sync"],
  ["Notion", "Knowledge", "Bases, páginas y automations"],
  ["Trello", "Project", "Cards, listas y automatización visual"],
  ["Slack", "Mensajería", "Canales, bots y resúmenes"],
  ["Discord", "Mensajería", "Comunidad, alertas y webhooks"],
  ["WhatsApp", "Mensajería", "Notificaciones y soporte"],
  ["Telegram", "Mensajería", "Bots y respuestas rápidas"],
  ["Twitter/X", "Social", "Publicación y escucha social"],
  ["LinkedIn", "Social", "Marca, outreach y contenido"],
  ["PayPal", "Payments", "Cobros, enlaces y conciliación"],
  ["Stripe", "Payments", "Pagos, suscripciones y checkout"],
  ["GitHub", "Dev", "Issues, actions y repos"],
  ["GitLab", "Dev", "Pipelines y merge requests"],
  ["Dropbox", "Storage", "Sync y archivos compartidos"],
  ["OneDrive", "Storage", "Sincronización empresarial"],
  ["AWS S3", "Storage", "Buckets y media pipelines"],
  ["Firebase", "Backend", "Realtime, auth y hosting"],
  ["RSS Feeds", "News", "Lectura, curación y alerts"],
  ["Zapier compatible", "Interop", "Puente de escenarios"],
  ["Groq AI", "AI", "Respuestas y clasificación"],
  ["Gemini AI", "AI", "Asistencia multimodal"],
  ["Claude AI", "AI", "Análisis y redacción"],
  ["OpenRouter AI", "AI", "Multi-model routing"],
] as const;

const TEMPLATE_PRESETS = [
  {
    id: "drive-pdf-notion",
    name: "Drive → PDF → Notion → WhatsApp",
    summary: "Convierte archivos y avisa al instante.",
    steps: [
      ["Nuevo archivo en Google Drive", "Google Drive", "trigger"] as const,
      ["Convertir a PDF", "API REST", "action"] as const,
      ["Guardar copia en Notion", "Notion", "action"] as const,
      ["Enviar notificación a WhatsApp", "WhatsApp", "output"] as const,
    ],
  },
  {
    id: "lead-slack-sheet",
    name: "Webhook → Enriquecer lead → Slack + Sheets",
    summary: "Captura leads y envíalos al equipo en segundos.",
    steps: [
      ["Capturar formulario vía Webhook", "Webhooks", "trigger"] as const,
      ["Enriquecer datos con IA", "Claude AI", "ai"] as const,
      ["Registrar lead en Google Sheets", "Google Sheets", "action"] as const,
      ["Alertar canal comercial", "Slack", "output"] as const,
    ],
  },
  {
    id: "rss-digest",
    name: "RSS → Resumen IA → Email diario",
    summary: "Monitoriza noticias y entrega un digest listo.",
    steps: [
      ["Leer nuevas entradas RSS", "RSS Feeds", "trigger"] as const,
      ["Resumir con Gemini AI", "Gemini AI", "ai"] as const,
      ["Clasificar por tema", "Groq AI", "condition"] as const,
      ["Enviar resumen por Email", "Email (SMTP/IMAP)", "output"] as const,
    ],
  },
];

const DEFAULT_FOLDERS: Folder[] = [
  { id: "folder_ops", name: "Operaciones", color: "#38bdf8" },
  { id: "folder_ai", name: "IA / Ideas", color: "#8b5cf6" },
  { id: "folder_personal", name: "Personal", color: "#f59e0b" },
];

const DEFAULT_NOTES: Note[] = [
  {
    id: "note_1",
    folderId: "folder_ops",
    title: "Checklist despliegue",
    content: "Verificar sandbox, activar webhook, revisar permisos y publicar versión.",
    updatedAt: new Date().toISOString(),
  },
  {
    id: "note_2",
    folderId: "folder_ai",
    title: "Idea IA onboarding",
    content: "Sugerir plantillas por rol: ventas, marketing, operaciones, soporte.",
    updatedAt: new Date().toISOString(),
  },
];

const DEFAULT_QUICK_LINKS: QuickLink[] = [
  { id: "link_1", label: "Roadmap", url: "https://github.com", color: "#1d4ed8", shape: "pill" },
  { id: "link_2", label: "Playbooks", url: "https://www.notion.so", color: "#0f172a", shape: "rounded" },
  { id: "link_3", label: "Monitor", url: "https://drive.google.com", color: "#2563eb", shape: "tile" },
];

const DEFAULT_WIDGETS: Widget[] = [
  {
    id: "widget_1",
    title: "Status Pulse",
    type: "html",
    createdAt: new Date().toISOString(),
    content:
      "<div style='font-family:Inter,system-ui;padding:14px;border-radius:20px;background:#0b1220;color:#fff;display:grid;gap:10px'><div style='display:flex;justify-content:space-between'><strong>Runtime</strong><span style='color:#57d5ff'>98.4%</span></div><div style='height:10px;background:#142033;border-radius:999px;overflow:hidden'><div style='width:78%;height:100%;background:linear-gradient(90deg,#41a5ff,#8b5cf6)'></div></div><small style='color:#94a3b8'>Sincronización local / cloud estable</small></div>",
  },
  {
    id: "widget_2",
    title: "Ops Notes",
    type: "markdown",
    createdAt: new Date().toISOString(),
    content: "- 3 flujos en sandbox\n- 12 conectores activos\n- 1 clave admin pendiente de exportar",
  },
];

const DEFAULT_GATE_APPS: GateApp[] = [
  {
    id: "gate_nexusid",
    name: "NEXUSID",
    url: "https://bazarduvi.github.io/NEXUSID/",
    type: "url",
    description: "PWA externa para identidad, workspace y módulos conectados.",
    adminOnly: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: "gate_code_ai_hub",
    name: "CODE-AI-HUB",
    url: "https://bazarduvi.github.io/CODE-AI-HUB/",
    type: "url",
    description: "Hub de código e IA para experimentar dentro de VICOgate.",
    adminOnly: true,
    createdAt: new Date().toISOString(),
  },
];

const DEFAULT_GATE_MESSAGES: GateMessage[] = [
  {
    id: "gate_msg_1",
    role: "assistant",
    content:
      "Asistente VICOgate listo. Puedo sugerirte cómo incrustar PWAs, evaluar permisos, preparar una biblioteca por URL o definir qué apps deben quedar visibles solo en modo admin.",
  },
];

const DEFAULT_ARTIFACTS: Artifact[] = [
  {
    id: "artifact_1",
    title: "Landing Widget",
    type: "html",
    prompt: "Landing minimal para portfolio con CTA y stats",
    code:
      "<!doctype html><html><body style='margin:0;font-family:Inter,system-ui;background:#020617;color:#fff;display:grid;place-items:center;min-height:100vh'><section style='padding:32px;max-width:680px;border-radius:24px;background:linear-gradient(180deg,#0f172a,#020617);border:1px solid rgba(255,255,255,.1)'><p style='color:#60a5fa'>Portfolio live</p><h1>Build, ship, iterate.</h1><p>Artefacto inicial para VICO Flow.</p><button style='padding:12px 18px;border:0;border-radius:999px;background:#2563eb;color:#fff'>Contactar</button></section></body></html>",
    createdAt: new Date().toISOString(),
  },
];

const DEFAULT_NEWS_SOURCES: NewsSource[] = [
  {
    id: "news_en_ai",
    name: "MIT Technology Review / AI",
    lang: "en",
    category: "AI",
    url: "https://www.technologyreview.com/topic/artificial-intelligence/",
    headlines: [
      "Agentic assistants are moving from chat to action.",
      "Smaller multimodal models are becoming deployable at the edge.",
    ],
  },
  {
    id: "news_en_code",
    name: "GitHub Blog / Engineering",
    lang: "en",
    category: "Coding",
    url: "https://github.blog/engineering/",
    headlines: [
      "Developer workflows are leaning into automation-first reviews.",
      "Design systems are becoming code-generation aware.",
    ],
  },
  {
    id: "news_en_science",
    name: "NASA Science",
    lang: "en",
    category: "Science",
    url: "https://science.nasa.gov/",
    headlines: [
      "New space observations reshape planetary atmosphere models.",
      "Scientific pipelines benefit from automation and data federation.",
    ],
  },
  {
    id: "news_es_ia",
    name: "Xataka / IA",
    lang: "es",
    category: "IA",
    url: "https://www.xataka.com/tag/inteligencia-artificial",
    headlines: [
      "La IA integrada gana valor cuando automatiza tareas repetitivas.",
      "Los agentes híbridos local/nube empiezan a tener casos reales de uso.",
    ],
  },
  {
    id: "news_es_planeta",
    name: "National Geographic España / Planeta",
    lang: "es",
    category: "Ecosistema planeta",
    url: "https://www.nationalgeographic.com.es/temas/medio-ambiente",
    headlines: [
      "La observación ambiental demanda paneles de datos más accesibles.",
      "Ciencia y automatización convergen para vigilar ecosistemas complejos.",
    ],
  },
  {
    id: "news_es_science",
    name: "Muy Interesante / Ciencia",
    lang: "es",
    category: "Ciencia",
    url: "https://www.muyinteresante.com/ciencia/",
    headlines: [
      "Los nuevos descubrimientos exigen flujos de trabajo más trazables.",
      "La divulgación científica abraza formatos rápidos y visuales.",
    ],
  },
];

const DEFAULT_SETTINGS: Settings = {
  darkMode: true,
  brandTheme: "electric",
  integratedAI: true,
  animationSpeed: 1,
  customAccent: "#41a5ff",
  offlineFirst: true,
  scriptEditorEnabled: true,
  rssLanguage: "both",
  rssEnabled: true,
  rssView: "ticker",
  tickerSpeed: 34,
  navbarShortcuts: ["flows", "vicogate", "vicoflow", "news"],
  sandboxMode: true,
  soundEnabled: false,
  securityProfile: "balanced",
  advancedHashes: true,
};

const DEFAULT_POMODORO: PomodoroState = {
  focusMinutes: 25,
  breakMinutes: 5,
  remaining: 25 * 60,
  running: false,
  mode: "focus",
};

function usePersistentState<T>(key: string, initialValue: T) {
  const [state, setState] = useState<T>(() => {
    if (typeof window === "undefined") return initialValue;
    try {
      const raw = window.localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initialValue;
    } catch {
      return initialValue;
    }
  });

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      window.localStorage.setItem(key, JSON.stringify(state));
    } catch {
      // Ignore write errors.
    }
  }, [key, state]);

  return [state, setState] as const;
}

function uid(prefix: string) {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

function nowStamp() {
  return new Date().toISOString();
}

async function hashString(value: string) {
  if (typeof window === "undefined" || !window.crypto?.subtle) return value;
  const digest = await window.crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest))
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
}

function downloadFile(filename: string, content: string, type = "application/json") {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

async function copyText(content: string) {
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(content);
    return true;
  }
  return false;
}

function makeStep(title: string, connector: string, kind: FlowKind, description: string, color: string): FlowStep {
  return { id: uid("step"), title, connector, kind, description, color };
}

function makeFlowFromPreset(index: number): Flow {
  const preset = TEMPLATE_PRESETS[index % TEMPLATE_PRESETS.length];
  const palette = ["#41a5ff", "#7c3aed", "#22c55e", "#f59e0b", "#f43f5e"];
  return {
    id: uid("flow"),
    name: preset.name,
    category: "Template",
    description: preset.summary,
    status: "draft",
    version: 1,
    versions: [{ version: 1, label: "Versión inicial", at: nowStamp() }],
    steps: preset.steps.map((entry, position) =>
      makeStep(
        entry[0],
        entry[1],
        entry[2],
        `${entry[0]} con ${entry[1]} listo para ejecutarse en modo sandbox o live.`,
        palette[position % palette.length],
      ),
    ),
  };
}

function tone(enabled: boolean) {
  if (!enabled || typeof window === "undefined" || !window.AudioContext) return;
  const context = new window.AudioContext();
  const oscillator = context.createOscillator();
  const gain = context.createGain();
  oscillator.connect(gain);
  gain.connect(context.destination);
  oscillator.type = "sine";
  oscillator.frequency.value = 880;
  gain.gain.value = 0.02;
  oscillator.start();
  oscillator.stop(context.currentTime + 0.06);
}

function summarizeSource(source: NewsSource) {
  const base = source.lang === "es" ? "IA detecta foco en" : "AI spots focus on";
  return `${base} ${source.category.toLowerCase()}, automatización utilizable y señales de adopción rápida.`;
}

function generateArtifact(prompt: string, type: ArtifactType) {
  const title = prompt.trim() || "Nuevo artefacto";
  if (type === "html") {
    return `<!doctype html>
<html lang="es">
  <body style="margin:0;font-family:Inter,system-ui;background:#020617;color:white;display:grid;place-items:center;min-height:100vh;">
    <section style="width:min(92vw,760px);padding:32px;border-radius:28px;background:linear-gradient(180deg,#0f172a,#020617);border:1px solid rgba(255,255,255,.12);box-shadow:0 20px 80px rgba(37,99,235,.22)">
      <p style="margin:0 0 8px;color:#60a5fa;letter-spacing:.16em;text-transform:uppercase;font-size:12px;">VICO Flow Sandbox</p>
      <h1 style="margin:0 0 14px;font-size:clamp(32px,5vw,56px);">${title}</h1>
      <p style="margin:0 0 22px;color:#cbd5e1;max-width:56ch;">Artefacto generado a partir del prompt: \"${title}\". Personalízalo, cópialo o descárgalo.</p>
      <div style="display:flex;gap:12px;flex-wrap:wrap">
        <button style="border:0;border-radius:999px;padding:12px 18px;background:linear-gradient(90deg,#2563eb,#7c3aed);color:white">Acción principal</button>
        <button style="border:1px solid rgba(255,255,255,.14);border-radius:999px;padding:12px 18px;background:transparent;color:white">Ver portafolio</button>
      </div>
    </section>
  </body>
</html>`;
  }

  if (type === "js") {
    return `export function initVicoflowWidget(target) {
  const state = { prompt: ${JSON.stringify(title)}, createdAt: new Date().toISOString() };
  target.innerHTML = \
    '<div style="padding:16px;border-radius:20px;background:#0f172a;color:white;font-family:Inter,system-ui">' +
    '<strong>${title}</strong><p style="color:#cbd5e1">Widget JS inicial para VICO Flow.</p></div>';
  return state;
}`;
  }

  if (type === "json") {
    return JSON.stringify(
      {
        name: title,
        type: "vico-artifact",
        sandbox: true,
        modules: ["ui", "automation", "preview"],
        prompt: title,
      },
      null,
      2,
    );
  }

  return `export default function GeneratedArtifact() {
  return (
    <section className="rounded-[28px] border border-white/10 bg-slate-950 p-8 text-white shadow-2xl shadow-blue-500/10">
      <p className="mb-2 text-xs uppercase tracking-[0.3em] text-sky-300">VICO Flow</p>
      <h1 className="mb-3 text-4xl font-semibold">${title}</h1>
      <p className="max-w-xl text-slate-300">Componente React generado desde prompt, listo para refinar.</p>
    </section>
  );
}`;
}

function generateAiSteps(goal: string): FlowStep[] {
  const lower = goal.toLowerCase();
  const steps: FlowStep[] = [];
  if (lower.includes("drive") || lower.includes("archivo")) {
    steps.push(makeStep("Detectar archivo nuevo", "Google Drive", "trigger", "Escucha cambios en una carpeta clave.", "#38bdf8"));
  } else {
    steps.push(makeStep("Escuchar entrada universal", "Webhooks", "trigger", "Entrada adaptable para formularios o apps externas.", "#38bdf8"));
  }

  if (lower.includes("pdf")) {
    steps.push(makeStep("Transformar archivo a PDF", "API REST", "action", "Conversión intermedia con validación de formato.", "#6366f1"));
  }

  if (lower.includes("notion")) {
    steps.push(makeStep("Guardar registro estructurado", "Notion", "action", "Crea o actualiza una página con metadata clave.", "#8b5cf6"));
  }

  if (lower.includes("email") || lower.includes("correo")) {
    steps.push(makeStep("Enviar email transaccional", "Email (SMTP/IMAP)", "output", "Entrega resumen y enlaces de seguimiento.", "#f59e0b"));
  }

  if (lower.includes("slack") || lower.includes("whatsapp") || lower.includes("telegram")) {
    const connector = lower.includes("slack") ? "Slack" : lower.includes("telegram") ? "Telegram" : "WhatsApp";
    steps.push(makeStep(`Notificar en ${connector}`, connector, "output", "Mensaje corto con contexto accionable.", "#22c55e"));
  }

  if (!steps.some((item) => item.kind === "ai")) {
    steps.splice(
      Math.min(1, steps.length),
      0,
      makeStep("Optimizar payload con IA", "Claude AI", "ai", "Añade campos, valida tono y sugiere pasos intermedios.", "#f43f5e"),
    );
  }

  if (steps.length < 4) {
    steps.push(makeStep("Registrar evento final", "Google Sheets", "action", "Auditoría ligera del flujo ejecutado.", "#14b8a6"));
  }

  return steps.slice(0, 5);
}

function formatTime(totalSeconds: number) {
  const minutes = Math.floor(totalSeconds / 60)
    .toString()
    .padStart(2, "0");
  const seconds = Math.floor(totalSeconds % 60)
    .toString()
    .padStart(2, "0");
  return `${minutes}:${seconds}`;
}

function LogoMark({ theme }: { theme: BrandTheme }) {
  return (
    <div className="relative flex items-center gap-3">
      <div
        className={cn(
          "logo-orb relative grid h-12 w-12 place-items-center overflow-hidden rounded-[18px] border border-white/10",
          theme === "gold"
            ? "bg-[linear-gradient(135deg,rgba(245,200,108,.35),rgba(229,158,47,.16),rgba(10,10,10,.95))]"
            : "bg-[linear-gradient(135deg,rgba(65,165,255,.35),rgba(124,58,237,.15),rgba(10,10,10,.95))]",
        )}
      >
        <span className="relative z-10 text-lg font-black tracking-[0.24em] text-white">VT</span>
      </div>
      <div>
        <p className="text-[11px] uppercase tracking-[0.45em] text-slate-400">Automation OS</p>
        <h1 className="text-lg font-semibold tracking-tight text-white">VICO Tékton</h1>
      </div>
    </div>
  );
}

function SectionCard({
  title,
  eyebrow,
  action,
  children,
  className,
}: {
  title: string;
  eyebrow?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section
      className={cn(
        "rounded-[28px] border border-white/10 bg-white/[0.04] p-5 shadow-[0_30px_120px_rgba(2,6,23,.35)] backdrop-blur-xl",
        className,
      )}
    >
      <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
        <div>
          {eyebrow ? <p className="mb-1 text-[11px] uppercase tracking-[0.35em] text-sky-300/80">{eyebrow}</p> : null}
          <h2 className="text-xl font-semibold tracking-tight text-white">{title}</h2>
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

function ToggleRow({
  label,
  hint,
  checked,
  onChange,
}: {
  label: string;
  hint: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <label className="flex items-start justify-between gap-4 rounded-[22px] border border-white/10 bg-black/20 p-4">
      <div>
        <p className="font-medium text-white">{label}</p>
        <p className="mt-1 text-sm text-slate-400">{hint}</p>
      </div>
      <button
        type="button"
        onClick={() => onChange(!checked)}
        className={cn(
          "relative mt-1 h-7 w-14 rounded-full transition",
          checked ? "bg-[var(--accent)]" : "bg-slate-800",
        )}
      >
        <span
          className={cn(
            "absolute top-1 h-5 w-5 rounded-full bg-white transition-transform",
            checked ? "translate-x-8" : "translate-x-1",
          )}
        />
      </button>
    </label>
  );
}

function MetricCard({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
      <p className="text-xs uppercase tracking-[0.28em] text-slate-400">{label}</p>
      <p className="mt-3 text-3xl font-semibold tracking-tight text-white">{value}</p>
      <p className="mt-1 text-sm text-slate-400">{hint}</p>
    </div>
  );
}

function StepBadge({ step, last }: { step: FlowStep; last: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <div className="relative flex flex-col items-center">
        <div className="grid h-11 w-11 place-items-center rounded-[16px] border border-white/10 bg-slate-950 text-white shadow-[0_0_30px_rgba(65,165,255,.18)]">
          <span style={{ color: step.color }}>{step.kind === "trigger" ? "◉" : step.kind === "ai" ? "✦" : step.kind === "condition" ? "◇" : step.kind === "output" ? "▣" : "◎"}</span>
        </div>
        {!last ? <div className="h-12 w-px bg-gradient-to-b from-[var(--accent)]/80 to-white/10" /> : null}
      </div>
      <div className="min-w-0 rounded-[22px] border border-white/10 bg-black/25 p-4">
        <div className="mb-2 flex flex-wrap items-center gap-2">
          <span className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-[10px] uppercase tracking-[0.25em] text-slate-300">
            {step.kind}
          </span>
          <span className="rounded-full px-2.5 py-1 text-[10px] uppercase tracking-[0.25em] text-white" style={{ backgroundColor: `${step.color}20`, color: step.color }}>
            {step.connector}
          </span>
        </div>
        <p className="font-medium text-white">{step.title}</p>
        <p className="mt-1 text-sm text-slate-400">{step.description}</p>
      </div>
    </div>
  );
}

function WidgetPreview({ widget }: { widget: Widget }) {
  return (
    <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
      <div className="mb-3 flex items-center justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-white">{widget.title}</p>
          <p className="text-xs uppercase tracking-[0.28em] text-slate-500">{widget.type}</p>
        </div>
        <span className="rounded-full border border-white/10 px-2 py-1 text-[10px] uppercase tracking-[0.28em] text-slate-300">live</span>
      </div>
      {widget.type === "html" ? (
        <iframe title={widget.title} srcDoc={widget.content} className="h-36 w-full rounded-2xl border border-white/10 bg-slate-950" />
      ) : (
        <pre className="overflow-auto whitespace-pre-wrap rounded-2xl border border-white/10 bg-slate-950/90 p-4 text-sm text-slate-300">{widget.content}</pre>
      )}
    </div>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = usePersistentState<TabId>("vicotekton_active_tab", "overview");
  const [settings, setSettings] = usePersistentState<Settings>("vicotekton_settings", DEFAULT_SETTINGS);
  const [flows, setFlows] = usePersistentState<Flow[]>("vicotekton_flows", [makeFlowFromPreset(0), makeFlowFromPreset(1)]);
  const [folders, setFolders] = usePersistentState<Folder[]>("vicotekton_folders", DEFAULT_FOLDERS);
  const [notes, setNotes] = usePersistentState<Note[]>("vicotekton_notes", DEFAULT_NOTES);
  const [quickLinks, setQuickLinks] = usePersistentState<QuickLink[]>("vicotekton_links", DEFAULT_QUICK_LINKS);
  const [widgets, setWidgets] = usePersistentState<Widget[]>("vicotekton_widgets", DEFAULT_WIDGETS);
  const [gateApps, setGateApps] = usePersistentState<GateApp[]>("vicotekton_gate_apps", DEFAULT_GATE_APPS);
  const [gateMessages, setGateMessages] = usePersistentState<GateMessage[]>("vicotekton_gate_messages", DEFAULT_GATE_MESSAGES);
  const [artifacts, setArtifacts] = usePersistentState<Artifact[]>("vicotekton_artifacts", DEFAULT_ARTIFACTS);
  const [newsSources, setNewsSources] = usePersistentState<NewsSource[]>("vicotekton_news_sources", DEFAULT_NEWS_SOURCES);
  const [pomodoro, setPomodoro] = usePersistentState<PomodoroState>("vicotekton_pomodoro", DEFAULT_POMODORO);
  const [uploadedAdminKey, setUploadedAdminKey] = usePersistentState<AdminKeyPayload | null>("vicotekton_admin_key", null);
  const [adminUnlocked, setAdminUnlocked] = usePersistentState<boolean>("vicotekton_admin_unlocked", false);

  const [selectedFlowId, setSelectedFlowId] = useState(flows[0]?.id ?? "");
  const [selectedFolderId, setSelectedFolderId] = useState(folders[0]?.id ?? "");
  const [selectedGateAppId, setSelectedGateAppId] = useState<string>("");
  const [flowPrompt, setFlowPrompt] = useState("Nuevo archivo en Drive, convertir a PDF, guardar en Notion y avisar por WhatsApp");
  const [sandboxLogs, setSandboxLogs] = useState<string[]>([]);
  const [connectorQuery, setConnectorQuery] = useState("");
  const [adminPassword, setAdminPassword] = useState("");
  const [adminFeedback, setAdminFeedback] = useState("Modo admin bloqueado.");
  const [flowStepDraft, setFlowStepDraft] = useState({
    title: "",
    connector: "API REST",
    kind: "action" as FlowKind,
    description: "",
  });
  const [folderDraft, setFolderDraft] = useState({ name: "", color: "#41a5ff" });
  const [noteDraft, setNoteDraft] = useState({ title: "", content: "" });
  const [linkDraft, setLinkDraft] = useState({ label: "", url: "https://", color: "#2563eb", shape: "pill" as LinkShape });
  const [widgetDraft, setWidgetDraft] = useState({ title: "", type: "html" as Widget["type"], content: "<div style='padding:12px;color:white'>Nuevo widget</div>" });
  const [gateDraft, setGateDraft] = useState({ name: "", url: "https://", description: "", type: "url" as GateApp["type"] });
  const [gatePrompt, setGatePrompt] = useState("");
  const [gateChatOpen, setGateChatOpen] = useState(true);
  const [artifactDraft, setArtifactDraft] = useState({ prompt: "Landing futurista para portafolio de automatización", title: "", type: "html" as ArtifactType, code: generateArtifact("Landing futurista para portafolio de automatización", "html") });
  const [sourceDraft, setSourceDraft] = useState({ name: "", lang: "es" as SourceLang, category: "IA", url: "https://", headline: "" });
  const [editingSourceId, setEditingSourceId] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [baseAdminHash, setBaseAdminHash] = useState("");

  useEffect(() => {
    document.documentElement.style.colorScheme = settings.darkMode ? "dark" : "light";
  }, [settings.darkMode]);

  useEffect(() => {
    void hashString(ADMIN_SECRET).then(setBaseAdminHash);
  }, []);

  useEffect(() => {
    if (!flows.some((flow) => flow.id === selectedFlowId)) {
      setSelectedFlowId(flows[0]?.id ?? "");
    }
  }, [flows, selectedFlowId]);

  useEffect(() => {
    if (!folders.some((folder) => folder.id === selectedFolderId)) {
      setSelectedFolderId(folders[0]?.id ?? "");
    }
  }, [folders, selectedFolderId]);

  useEffect(() => {
    const visibleGateApp = gateApps.find((item) => item.id === selectedGateAppId && (!item.adminOnly || adminUnlocked));
    if (!visibleGateApp) {
      const firstVisible = gateApps.find((item) => !item.adminOnly || adminUnlocked);
      setSelectedGateAppId(firstVisible?.id ?? "");
    }
  }, [gateApps, selectedGateAppId, adminUnlocked]);

  useEffect(() => {
    if (!pomodoro.running) return;
    const timer = window.setInterval(() => {
      setPomodoro((current) => {
        if (current.remaining <= 1) {
          const nextMode = current.mode === "focus" ? "break" : "focus";
          const nextRemaining = (nextMode === "focus" ? current.focusMinutes : current.breakMinutes) * 60;
          return { ...current, mode: nextMode, remaining: nextRemaining, running: false };
        }
        return { ...current, remaining: current.remaining - 1 };
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, [pomodoro.running, setPomodoro]);

  useEffect(() => {
    const onFullscreenChange = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", onFullscreenChange);
    return () => document.removeEventListener("fullscreenchange", onFullscreenChange);
  }, []);

  const palette = useMemo(() => {
    if (settings.brandTheme === "gold") {
      return {
        accent: settings.customAccent || "#f5c86c",
        secondary: "#e59e2f",
        glow: "rgba(245,200,108,.28)",
      };
    }
    return {
      accent: settings.customAccent || "#41a5ff",
      secondary: "#0ea5e9",
      glow: "rgba(65,165,255,.28)",
    };
  }, [settings.brandTheme, settings.customAccent]);

  const shellStyle = {
    ["--accent" as string]: palette.accent,
    ["--accent-2" as string]: palette.secondary,
    ["--accent-glow" as string]: palette.glow,
    ["--ticker-duration" as string]: `${Math.max(14, 60 - settings.tickerSpeed)}s`,
  } as CSSProperties;

  const selectedFlow = flows.find((flow) => flow.id === selectedFlowId) ?? flows[0];
  const selectedGateApp = gateApps.find((item) => item.id === selectedGateAppId && (!item.adminOnly || adminUnlocked));
  const currentFolder = folders.find((folder) => folder.id === selectedFolderId) ?? folders[0];

  const filteredConnectors = CONNECTORS.filter(
    (connector) =>
      connector[0].toLowerCase().includes(connectorQuery.toLowerCase()) ||
      connector[1].toLowerCase().includes(connectorQuery.toLowerCase()) ||
      connector[2].toLowerCase().includes(connectorQuery.toLowerCase()),
  );

  const visibleSources = newsSources.filter((source) => {
    if (settings.rssLanguage === "both") return true;
    return source.lang === settings.rssLanguage;
  });

  const tickerItems = visibleSources.flatMap((source) => source.headlines.map((headline) => `${source.name}: ${headline}`));

  const navShortcuts = TAB_ITEMS.filter((tab) => settings.navbarShortcuts.includes(tab.id));
  const currentNotes = notes.filter((note) => note.folderId === currentFolder?.id);
  const visibleGateApps = gateApps.filter((app) => !app.adminOnly || adminUnlocked);

  const updateSettings = <K extends keyof Settings>(key: K, value: Settings[K]) => {
    setSettings((current) => ({ ...current, [key]: value }));
  };

  const patchSelectedFlow = (recipe: (flow: Flow) => Flow) => {
    setFlows((current) => current.map((flow) => (flow.id === selectedFlowId ? recipe(flow) : flow)));
  };

  const addNewFlow = (presetIndex?: number) => {
    const flow = typeof presetIndex === "number" ? makeFlowFromPreset(presetIndex) : makeFlowFromPreset(flows.length % TEMPLATE_PRESETS.length);
    setFlows((current) => [flow, ...current]);
    setSelectedFlowId(flow.id);
    tone(settings.soundEnabled);
  };

  const addStepToSelectedFlow = () => {
    if (!selectedFlow || !flowStepDraft.title.trim()) return;
    const colorMap: Record<FlowKind, string> = {
      trigger: "#38bdf8",
      action: "#8b5cf6",
      ai: "#f43f5e",
      condition: "#22c55e",
      output: "#f59e0b",
    };
    patchSelectedFlow((flow) => ({
      ...flow,
      steps: [
        ...flow.steps,
        makeStep(
          flowStepDraft.title.trim(),
          flowStepDraft.connector,
          flowStepDraft.kind,
          flowStepDraft.description.trim() || "Paso personalizado añadido por el usuario.",
          colorMap[flowStepDraft.kind],
        ),
      ],
      version: flow.version + 1,
      versions: [{ version: flow.version + 1, label: "Paso añadido", at: nowStamp() }, ...flow.versions],
    }));
    setFlowStepDraft({ title: "", connector: "API REST", kind: "action", description: "" });
    tone(settings.soundEnabled);
  };

  const cloneSelectedFlow = () => {
    if (!selectedFlow) return;
    const cloned: Flow = {
      ...selectedFlow,
      id: uid("flow"),
      name: `${selectedFlow.name} — Clon`,
      status: "draft",
      versions: [{ version: 1, label: "Clonado desde editor premium", at: nowStamp() }],
      version: 1,
      steps: selectedFlow.steps.map((step) => ({ ...step, id: uid("step") })),
    };
    setFlows((current) => [cloned, ...current]);
    setSelectedFlowId(cloned.id);
    tone(settings.soundEnabled);
  };

  const runSandbox = () => {
    if (!selectedFlow) return;
    patchSelectedFlow((flow) => ({
      ...flow,
      status: "sandbox",
      versions: [{ version: flow.version, label: "Sandbox ejecutado", at: nowStamp() }, ...flow.versions],
    }));
    setSandboxLogs([]);
    selectedFlow.steps.forEach((step, index) => {
      window.setTimeout(() => {
        setSandboxLogs((current) => [
          ...current,
          `${index + 1}. ${step.title} • ${step.connector} • ${step.kind === "ai" ? "IA enriqueciendo payload" : "OK"}`,
        ]);
      }, index * Math.max(220, 850 / Math.max(settings.animationSpeed, 0.6)));
    });
    tone(settings.soundEnabled);
  };

  const deploySelectedFlow = () => {
    if (!selectedFlow) return;
    patchSelectedFlow((flow) => ({
      ...flow,
      status: "live",
      version: flow.version + 1,
      versions: [{ version: flow.version + 1, label: "Deploy one-click", at: nowStamp() }, ...flow.versions],
    }));
    setSandboxLogs((current) => [...current, "Flow desplegado en modo live. Runtime listo."]);
    tone(settings.soundEnabled);
  };

  const applyAiSuggestion = () => {
    if (!selectedFlow || !settings.integratedAI) return;
    const steps = generateAiSteps(flowPrompt);
    patchSelectedFlow((flow) => ({
      ...flow,
      steps,
      description: `Blueprint IA para: ${flowPrompt}`,
      version: flow.version + 1,
      versions: [{ version: flow.version + 1, label: "IA generó blueprint", at: nowStamp() }, ...flow.versions],
    }));
    setSandboxLogs(["IA integrada creó una secuencia optimizada de 3–5 pasos claros."]);
    tone(settings.soundEnabled);
  };

  const addFolder = () => {
    if (!folderDraft.name.trim()) return;
    const folder = { id: uid("folder"), name: folderDraft.name.trim(), color: folderDraft.color };
    setFolders((current) => [folder, ...current]);
    setSelectedFolderId(folder.id);
    setFolderDraft({ name: "", color: folderDraft.color });
    tone(settings.soundEnabled);
  };

  const addNote = () => {
    if (!currentFolder || !noteDraft.title.trim()) return;
    const note: Note = {
      id: uid("note"),
      folderId: currentFolder.id,
      title: noteDraft.title.trim(),
      content: noteDraft.content.trim(),
      updatedAt: nowStamp(),
    };
    setNotes((current) => [note, ...current]);
    setNoteDraft({ title: "", content: "" });
    tone(settings.soundEnabled);
  };

  const addQuickLink = () => {
    if (!linkDraft.label.trim() || !linkDraft.url.trim()) return;
    setQuickLinks((current) => [
      {
        id: uid("link"),
        label: linkDraft.label.trim(),
        url: linkDraft.url.trim(),
        color: linkDraft.color,
        shape: linkDraft.shape,
      },
      ...current,
    ]);
    setLinkDraft({ label: "", url: "https://", color: "#2563eb", shape: "pill" });
    tone(settings.soundEnabled);
  };

  const addWidget = () => {
    if (!widgetDraft.title.trim() || !widgetDraft.content.trim()) return;
    setWidgets((current) => [
      {
        id: uid("widget"),
        title: widgetDraft.title.trim(),
        type: widgetDraft.type,
        content: widgetDraft.content,
        createdAt: nowStamp(),
      },
      ...current,
    ]);
    setWidgetDraft({ title: "", type: "html", content: "<div style='padding:12px;color:white'>Nuevo widget</div>" });
    tone(settings.soundEnabled);
  };

  const addGateApp = () => {
    if (!gateDraft.name.trim()) return;
    setGateApps((current) => [
      {
        id: uid("gate"),
        name: gateDraft.name.trim(),
        url: gateDraft.url.trim(),
        type: gateDraft.type,
        description: gateDraft.description.trim() || "Módulo añadido manualmente a la biblioteca.",
        createdAt: nowStamp(),
      },
      ...current,
    ]);
    setGateDraft({ name: "", url: "https://", description: "", type: "url" });
    tone(settings.soundEnabled);
  };

  const handleGateFileUpload = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const extension = file.name.split(".").pop()?.toLowerCase() ?? "html";
    const fileType = extension === "html" ? "html" : extension === "js" ? "js" : extension === "json" ? "json" : "zip";

    if (fileType === "html" || fileType === "js" || fileType === "json") {
      const content = await file.text();
      setGateApps((current) => [
        {
          id: uid("gate"),
          name: file.name,
          type: fileType,
          srcDoc: fileType === "html" ? content : `<pre style='white-space:pre-wrap;padding:18px;color:white;background:#020617;font-family:ui-monospace,monospace'>${content
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")}</pre>`,
          description: `Archivo ${fileType.toUpperCase()} cargado en biblioteca local de VICOgate.`,
          createdAt: nowStamp(),
        },
        ...current,
      ]);
    } else {
      setGateApps((current) => [
        {
          id: uid("gate"),
          name: file.name,
          type: "zip",
          description: "ZIP registrado. Puedes conservarlo en biblioteca para administración o despliegues externos.",
          createdAt: nowStamp(),
        },
        ...current,
      ]);
    }

    tone(settings.soundEnabled);
    event.currentTarget.value = "";
  };

  const replyGateAssistant = (prompt: string) => {
    const lower = prompt.toLowerCase();
    if (lower.includes("iframe") || lower.includes("embed")) {
      return "Usa URL para entornos abiertos y HTML local para sandbox. Si una PWA externa bloquea iframe, muestra CTA de apertura en nueva pestaña y conserva su tarjeta en biblioteca.";
    }
    if (lower.includes("admin")) {
      return "Marca la app como adminOnly cuando la biblioteca deba ocultarla a usuarios estándar. Las dos PWAs por defecto ya obedecen esa regla.";
    }
    if (lower.includes("sandbox") || lower.includes("preview")) {
      return "Para sandbox seguro, carga HTML/JS/JSON por separado, registra metadata y ejecuta previews dentro de contenedores aislados antes de publicar.";
    }
    return "Sugerencia VICOgate: combina biblioteca por URL, cargas locales y políticas de permisos. Prioriza módulos reutilizables, aislamiento por origen y activación contextual por rol.";
  };

  const sendGatePrompt = () => {
    if (!gatePrompt.trim()) return;
    const userMessage: GateMessage = { id: uid("gate_msg"), role: "user", content: gatePrompt.trim() };
    const assistantMessage: GateMessage = { id: uid("gate_msg"), role: "assistant", content: replyGateAssistant(gatePrompt.trim()) };
    setGateMessages((current) => [...current, userMessage, assistantMessage]);
    setGatePrompt("");
    tone(settings.soundEnabled);
  };

  const regenerateArtifact = () => {
    const nextCode = generateArtifact(artifactDraft.prompt, artifactDraft.type);
    setArtifactDraft((current) => ({
      ...current,
      title: current.title || current.prompt || "Artefacto",
      code: nextCode,
    }));
    tone(settings.soundEnabled);
  };

  const saveArtifact = () => {
    const title = artifactDraft.title.trim() || artifactDraft.prompt.trim() || `Artefacto ${artifactDraft.type.toUpperCase()}`;
    setArtifacts((current) => [
      {
        id: uid("artifact"),
        title,
        type: artifactDraft.type,
        prompt: artifactDraft.prompt,
        code: artifactDraft.code,
        createdAt: nowStamp(),
      },
      ...current,
    ]);
    tone(settings.soundEnabled);
  };

  const saveSource = () => {
    if (!sourceDraft.name.trim() || !sourceDraft.url.trim()) return;
    const source: NewsSource = {
      id: editingSourceId ?? uid("source"),
      name: sourceDraft.name.trim(),
      lang: sourceDraft.lang,
      category: sourceDraft.category.trim(),
      url: sourceDraft.url.trim(),
      headlines: [sourceDraft.headline.trim() || "Nueva fuente manual añadida al radar de IA."],
      dynamic: true,
    };
    if (editingSourceId) {
      setNewsSources((current) => current.map((item) => (item.id === editingSourceId ? source : item)));
    } else {
      setNewsSources((current) => [source, ...current]);
    }
    setSourceDraft({ name: "", lang: "es", category: "IA", url: "https://", headline: "" });
    setEditingSourceId(null);
    tone(settings.soundEnabled);
  };

  const editSource = (source: NewsSource) => {
    setEditingSourceId(source.id);
    setSourceDraft({
      name: source.name,
      lang: source.lang,
      category: source.category,
      url: source.url,
      headline: source.headlines[0] ?? "",
    });
  };

  const removeSource = (sourceId: string) => {
    setNewsSources((current) => current.filter((item) => item.id !== sourceId));
    if (editingSourceId === sourceId) {
      setEditingSourceId(null);
      setSourceDraft({ name: "", lang: "es", category: "IA", url: "https://", headline: "" });
    }
    tone(settings.soundEnabled);
  };

  const exportFlows = () => {
    downloadFile(
      "vico-tekton-flows.json",
      JSON.stringify(
        {
          exportedAt: nowStamp(),
          app: "VICO Tékton",
          flows,
        },
        null,
        2,
      ),
    );
    tone(settings.soundEnabled);
  };

  const handleImportFlows = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text()) as { flows?: Flow[] } | Flow[];
      const imported = Array.isArray(parsed) ? parsed : parsed.flows;
      if (Array.isArray(imported) && imported.length > 0) {
        setFlows(imported);
        setSelectedFlowId(imported[0].id);
      }
    } catch {
      // Ignore malformed files.
    }
    event.currentTarget.value = "";
  };

  const exportAdminKey = async () => {
    const hash = uploadedAdminKey?.hash || baseAdminHash || (await hashString(ADMIN_SECRET));
    const payload: AdminKeyPayload = {
      label: "VICO Tékton Master Key",
      format: "SHA-246 JSON",
      algorithm: "SHA-246",
      hashEngine: "SHA-256 / WebCrypto",
      hash,
      createdAt: nowStamp(),
      permissions: ["advanced-visual-editor", "premium-marketplace", "apk-pwa-export"],
    };
    setUploadedAdminKey(payload);
    downloadFile("vico-master-key.json", JSON.stringify(payload, null, 2));
    tone(settings.soundEnabled);
  };

  const handleImportAdminKey = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const payload = JSON.parse(await file.text()) as AdminKeyPayload;
      if (payload.hash) {
        setUploadedAdminKey(payload);
        setAdminFeedback("Llave maestra cargada. Lista para validar.");
      }
    } catch {
      setAdminFeedback("No se pudo leer la llave JSON.");
    }
    event.currentTarget.value = "";
  };

  const unlockAdmin = async () => {
    const candidate = await hashString(adminPassword.trim());
    const target = uploadedAdminKey?.hash || baseAdminHash;
    if (candidate && target && candidate === target) {
      setAdminUnlocked(true);
      setAdminFeedback("Modo admin desbloqueado. Premium activo.");
      tone(settings.soundEnabled);
      return;
    }
    setAdminUnlocked(false);
    setAdminFeedback("Clave inválida. Verifica la contraseña o importa la llave JSON.");
  };

  const exportPwaSpec = () => {
    const payload = {
      app: "VICO Tékton",
      mode: "PWA export profile",
      premium: true,
      createdAt: nowStamp(),
      manifest: {
        name: "VICO Tékton",
        display: "standalone",
        theme_color: settings.brandTheme === "gold" ? "#120c02" : "#030712",
      },
      distribution: ["Play Store", "App Store", "PWA standalone"],
      flows: flows.length,
    };
    downloadFile("vico-pwa-export-spec.json", JSON.stringify(payload, null, 2));
    tone(settings.soundEnabled);
  };

  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
    } catch {
      // Ignore fullscreen errors.
    }
  };

  return (
    <div
      className={cn(
        "min-h-screen transition-colors duration-500",
        settings.darkMode ? "bg-[#05070d] text-white" : "bg-[#eff5ff] text-slate-950",
      )}
      style={shellStyle}
    >
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(65,165,255,.18),transparent_34%),radial-gradient(circle_at_bottom_right,rgba(124,58,237,.16),transparent_30%),linear-gradient(180deg,rgba(255,255,255,.04),transparent)]" />
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.03)_1px,transparent_1px)] bg-[size:56px_56px] opacity-[0.06]" />
      </div>

      <header className="sticky top-0 z-40 border-b border-white/10 bg-black/30 backdrop-blur-2xl">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
            <div className="flex flex-wrap items-center gap-4">
              <LogoMark theme={settings.brandTheme} />
              <div className="hidden h-10 w-px bg-white/10 lg:block" />
              <div className="flex flex-wrap gap-2">
                {navShortcuts.map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => {
                      setActiveTab(tab.id);
                      tone(settings.soundEnabled);
                    }}
                    className={cn(
                      "rounded-full border px-3 py-1.5 text-sm transition",
                      activeTab === tab.id
                        ? "border-transparent bg-[var(--accent)] text-white shadow-[0_0_30px_var(--accent-glow)]"
                        : "border-white/10 bg-white/5 text-slate-300 hover:border-white/20 hover:text-white",
                    )}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-3 xl:items-end">
              {settings.rssEnabled && settings.rssView === "ticker" && tickerItems.length > 0 ? (
                <div className="ticker-shell max-w-full overflow-hidden rounded-full border border-white/10 bg-white/[0.04] px-3 py-2 text-xs text-slate-300">
                  <div className="ticker-track whitespace-nowrap">
                    {tickerItems.concat(tickerItems).map((item, index) => (
                      <span key={`${item}-${index}`} className="mr-10 inline-flex items-center gap-2">
                        <span className="text-[var(--accent)]">●</span>
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              ) : null}

              <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                <div className="flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-2">
                  <button
                    type="button"
                    onClick={() => {
                      setPomodoro((current) => ({ ...current, running: !current.running }));
                      tone(settings.soundEnabled);
                    }}
                    className="rounded-full bg-[var(--accent)] px-3 py-1 text-xs font-semibold text-white"
                  >
                    {pomodoro.running ? "Pausa" : "Pomodoro"}
                  </button>
                  <div>
                    <p className="text-[10px] uppercase tracking-[0.3em] text-slate-400">{pomodoro.mode}</p>
                    <p className="text-sm font-semibold text-white">{formatTime(pomodoro.remaining)}</p>
                  </div>
                  <div className="hidden items-center gap-2 md:flex">
                    <input
                      type="number"
                      min={5}
                      max={90}
                      value={pomodoro.focusMinutes}
                      onChange={(event) => {
                        const value = Number(event.target.value);
                        setPomodoro((current) => ({
                          ...current,
                          focusMinutes: value,
                          remaining: current.mode === "focus" && !current.running ? value * 60 : current.remaining,
                        }));
                      }}
                      className="w-16 rounded-full border border-white/10 bg-black/30 px-3 py-1 text-sm text-white outline-none"
                    />
                    <span className="text-xs text-slate-400">/</span>
                    <input
                      type="number"
                      min={3}
                      max={30}
                      value={pomodoro.breakMinutes}
                      onChange={(event) => {
                        const value = Number(event.target.value);
                        setPomodoro((current) => ({
                          ...current,
                          breakMinutes: value,
                          remaining: current.mode === "break" && !current.running ? value * 60 : current.remaining,
                        }));
                      }}
                      className="w-16 rounded-full border border-white/10 bg-black/30 px-3 py-1 text-sm text-white outline-none"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => updateSettings("darkMode", !settings.darkMode)}
                  className="rounded-full border border-white/10 bg-white/[0.04] px-4 py-2 text-sm text-white transition hover:border-white/20"
                >
                  {settings.darkMode ? "Dark on" : "Dark off"}
                </button>
                <button
                  type="button"
                  onClick={toggleFullscreen}
                  className="rounded-full border border-white/10 bg-white/[0.04] px-4 py-2 text-sm text-white transition hover:border-white/20"
                >
                  {isFullscreen ? "Salir fullscreen" : "Fullscreen"}
                </button>
                <span
                  className={cn(
                    "rounded-full border px-4 py-2 text-sm",
                    adminUnlocked ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-300" : "border-white/10 bg-white/[0.04] text-slate-300",
                  )}
                >
                  {adminUnlocked ? "Admin premium" : "Modo usuario"}
                </span>
              </div>
            </div>
          </div>

          <div className="mt-5 flex gap-2 overflow-x-auto pb-1">
            {TAB_ITEMS.map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  setActiveTab(tab.id);
                  tone(settings.soundEnabled);
                }}
                className={cn(
                  "shrink-0 rounded-full border px-4 py-2 text-sm transition",
                  activeTab === tab.id
                    ? "border-transparent bg-white text-slate-950 shadow-[0_10px_40px_rgba(255,255,255,.12)]"
                    : "border-white/10 bg-white/[0.04] text-slate-300 hover:border-white/20 hover:text-white",
                )}
              >
                <span className="mr-2 text-[var(--accent)]">{tab.icon}</span>
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </header>

      <main className="relative mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-8">
        <section className="mb-6 grid gap-6 lg:grid-cols-[1.5fr_1fr]">
          <div className="rounded-[32px] border border-white/10 bg-[linear-gradient(135deg,rgba(255,255,255,.08),rgba(255,255,255,.03),rgba(0,0,0,.28))] p-6 shadow-[0_30px_100px_var(--accent-glow)]">
            <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
              <div className="max-w-3xl">
                <p className="mb-3 inline-flex rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs uppercase tracking-[0.32em] text-slate-300">
                  PWA modular • minimalismo premium • offline-first
                </p>
                <h2 className="max-w-2xl text-4xl font-semibold tracking-tight text-white sm:text-5xl">
                  Automatización visual más simple que Make.com, más elegante y lista para evolucionar.
                </h2>
                <p className="mt-4 max-w-2xl text-base leading-7 text-slate-300 sm:text-lg">
                  Diseña flujos en 3–5 pasos claros, prueba en sandbox, activa IA contextual, administra módulos premium y ejecuta experiencias híbridas local / nube desde una sola interfaz fullscreen.
                </p>
              </div>
              <div className="grid gap-3 sm:grid-cols-2 lg:w-[320px]">
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab("flows");
                    tone(settings.soundEnabled);
                  }}
                  className="rounded-[22px] bg-[linear-gradient(90deg,var(--accent),var(--accent-2))] px-5 py-4 text-left text-white shadow-[0_24px_60px_var(--accent-glow)]"
                >
                  <span className="block text-xs uppercase tracking-[0.28em] text-white/70">Start</span>
                  <span className="mt-1 block text-lg font-semibold">Crear flujo</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab("vicogate");
                    tone(settings.soundEnabled);
                  }}
                  className="rounded-[22px] border border-white/10 bg-black/25 px-5 py-4 text-left text-white"
                >
                  <span className="block text-xs uppercase tracking-[0.28em] text-slate-400">Hub</span>
                  <span className="mt-1 block text-lg font-semibold">Abrir VICOgate</span>
                </button>
              </div>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-1">
            <MetricCard label="Flows" value={`${flows.length}`} hint="Versionados y listos para clonar o desplegar." />
            <MetricCard label="Conectores" value={`${CONNECTORS.length}`} hint="Universales, reutilizables y en crecimiento." />
            <MetricCard label="Modo" value={settings.offlineFirst ? "Hybrid" : "Cloud"} hint="Local-first con sincronización inteligente." />
          </div>
        </section>

        {activeTab === "overview" ? (
          <div className="grid gap-6 xl:grid-cols-[1.2fr_.8fr]">
            <div className="space-y-6">
              <SectionCard title="Plantillas inteligentes" eyebrow="Quick launch">
                <div className="grid gap-4 md:grid-cols-3">
                  {TEMPLATE_PRESETS.map((preset, index) => (
                    <div key={preset.id} className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                      <p className="text-sm font-semibold text-white">{preset.name}</p>
                      <p className="mt-2 text-sm text-slate-400">{preset.summary}</p>
                      <div className="mt-4 flex flex-wrap gap-2">
                        {preset.steps.map((step) => (
                          <span key={step[0]} className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-xs text-slate-300">
                            {step[1]}
                          </span>
                        ))}
                      </div>
                      <button
                        type="button"
                        onClick={() => addNewFlow(index)}
                        className="mt-4 rounded-full bg-[var(--accent)] px-4 py-2 text-sm font-medium text-white"
                      >
                        Usar plantilla
                      </button>
                    </div>
                  ))}
                </div>
              </SectionCard>

              <SectionCard
                title="Botones dinámicos por links"
                eyebrow="Launcher"
                action={<span className="rounded-full border border-white/10 px-3 py-1 text-xs uppercase tracking-[0.28em] text-slate-400">shapes + colores</span>}
              >
                <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
                  <div className="flex flex-wrap gap-3">
                    {quickLinks.map((link) => (
                      <a
                        key={link.id}
                        href={link.url}
                        target="_blank"
                        rel="noreferrer"
                        className={cn(
                          "inline-flex items-center gap-2 px-5 py-3 text-sm font-medium text-white shadow-[0_20px_50px_rgba(15,23,42,.35)] transition hover:scale-[1.02]",
                          link.shape === "pill" && "rounded-full",
                          link.shape === "rounded" && "rounded-[22px]",
                          link.shape === "tile" && "rounded-[18px]",
                        )}
                        style={{ backgroundColor: link.color }}
                      >
                        ↗ {link.label}
                      </a>
                    ))}
                  </div>
                  <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                    <div className="grid gap-3">
                      <input
                        value={linkDraft.label}
                        onChange={(event) => setLinkDraft((current) => ({ ...current, label: event.target.value }))}
                        placeholder="Nombre del botón"
                        className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                      />
                      <input
                        value={linkDraft.url}
                        onChange={(event) => setLinkDraft((current) => ({ ...current, url: event.target.value }))}
                        placeholder="https://"
                        className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                      />
                      <div className="grid grid-cols-2 gap-3">
                        <input
                          type="color"
                          value={linkDraft.color}
                          onChange={(event) => setLinkDraft((current) => ({ ...current, color: event.target.value }))}
                          className="h-12 w-full rounded-2xl border border-white/10 bg-black/30 p-2"
                        />
                        <select
                          value={linkDraft.shape}
                          onChange={(event) => setLinkDraft((current) => ({ ...current, shape: event.target.value as LinkShape }))}
                          className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                        >
                          <option value="pill">Pill</option>
                          <option value="rounded">Rounded</option>
                          <option value="tile">Tile</option>
                        </select>
                      </div>
                      <button type="button" onClick={addQuickLink} className="rounded-2xl bg-[var(--accent)] px-4 py-3 text-sm font-medium text-white">
                        Añadir botón
                      </button>
                    </div>
                  </div>
                </div>
              </SectionCard>

              <SectionCard title="Widgets de dashboard" eyebrow="Scripts / códigos con guardado automático">
                <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
                  <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                    <div className="grid gap-3">
                      <input
                        value={widgetDraft.title}
                        onChange={(event) => setWidgetDraft((current) => ({ ...current, title: event.target.value }))}
                        placeholder="Título del widget"
                        className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                      />
                      <select
                        value={widgetDraft.type}
                        onChange={(event) => setWidgetDraft((current) => ({ ...current, type: event.target.value as Widget["type"] }))}
                        className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                      >
                        <option value="html">HTML preview</option>
                        <option value="markdown">Markdown</option>
                        <option value="json">JSON</option>
                      </select>
                      <textarea
                        value={widgetDraft.content}
                        onChange={(event) => setWidgetDraft((current) => ({ ...current, content: event.target.value }))}
                        rows={8}
                        className="rounded-[22px] border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                      />
                      <button type="button" onClick={addWidget} className="rounded-2xl bg-[var(--accent)] px-4 py-3 text-sm font-medium text-white">
                        Guardar widget
                      </button>
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                    {widgets.map((widget) => (
                      <WidgetPreview key={widget.id} widget={widget} />
                    ))}
                  </div>
                </div>
              </SectionCard>
            </div>

            <div className="space-y-6">
              <SectionCard title="Actividad del flujo seleccionado" eyebrow="Live status">
                {selectedFlow ? (
                  <div className="space-y-4">
                    <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <p className="text-lg font-semibold text-white">{selectedFlow.name}</p>
                          <p className="mt-1 text-sm text-slate-400">{selectedFlow.description}</p>
                        </div>
                        <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs uppercase tracking-[0.25em] text-slate-300">
                          v{selectedFlow.version}
                        </span>
                      </div>
                      <div className="mt-4 flex flex-wrap gap-2">
                        {selectedFlow.steps.map((step) => (
                          <span key={step.id} className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-300">
                            {step.connector}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                      <p className="mb-2 text-sm font-medium text-white">Sandbox trace</p>
                      <div className="grid gap-2">
                        {sandboxLogs.length > 0 ? sandboxLogs.map((log, index) => (
                          <div key={`${log}-${index}`} className="rounded-2xl border border-white/10 bg-slate-950/90 px-3 py-2 text-sm text-slate-300">
                            {log}
                          </div>
                        )) : <p className="text-sm text-slate-400">Ejecuta el sandbox para ver trazas aquí.</p>}
                      </div>
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-slate-400">Crea un flujo para empezar.</p>
                )}
              </SectionCard>

              <SectionCard title="Premium desbloqueable" eyebrow="Modo admin">
                <div className="grid gap-3">
                  <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                    <p className="font-medium text-white">Editor visual avanzado</p>
                    <p className="mt-1 text-sm text-slate-400">Clonación profunda, versiones protegidas y despliegue one-click.</p>
                  </div>
                  <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                    <p className="font-medium text-white">Marketplace interno</p>
                    <p className="mt-1 text-sm text-slate-400">Módulos premium, bundles por vertical y monetización directa.</p>
                  </div>
                  <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                    <p className="font-medium text-white">Exportación APK / PWA</p>
                    <p className="mt-1 text-sm text-slate-400">Perfil listo para publicación y distribución móvil.</p>
                  </div>
                </div>
              </SectionCard>
            </div>
          </div>
        ) : null}

        {activeTab === "flows" ? (
          <div className="grid gap-6 xl:grid-cols-[340px_1fr]">
            <div className="space-y-6">
              <SectionCard
                title="Biblioteca de flows"
                eyebrow="Versionado y sandbox"
                action={
                  <button type="button" onClick={() => addNewFlow()} className="rounded-full bg-[var(--accent)] px-4 py-2 text-sm font-medium text-white">
                    Nuevo flow
                  </button>
                }
              >
                <div className="grid gap-3">
                  {flows.map((flow) => (
                    <button
                      key={flow.id}
                      type="button"
                      onClick={() => {
                        setSelectedFlowId(flow.id);
                        tone(settings.soundEnabled);
                      }}
                      className={cn(
                        "rounded-[22px] border p-4 text-left transition",
                        selectedFlowId === flow.id
                          ? "border-transparent bg-white text-slate-950 shadow-[0_18px_50px_rgba(255,255,255,.14)]"
                          : "border-white/10 bg-black/20 text-white hover:border-white/20",
                      )}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="font-semibold">{flow.name}</p>
                          <p className={cn("mt-1 text-sm", selectedFlowId === flow.id ? "text-slate-600" : "text-slate-400")}>{flow.description}</p>
                        </div>
                        <span className="rounded-full border border-black/10 bg-black/5 px-2 py-1 text-[10px] uppercase tracking-[0.28em]">
                          {flow.status}
                        </span>
                      </div>
                      <div className="mt-3 flex flex-wrap gap-2">
                        {flow.steps.slice(0, 4).map((step) => (
                          <span key={step.id} className="rounded-full border border-black/10 bg-black/5 px-2 py-1 text-[10px] uppercase tracking-[0.2em]">
                            {step.connector}
                          </span>
                        ))}
                      </div>
                    </button>
                  ))}
                </div>
              </SectionCard>

              <SectionCard title="IA integrada" eyebrow="Blueprint assistant">
                <div className="grid gap-3">
                  <textarea
                    value={flowPrompt}
                    onChange={(event) => setFlowPrompt(event.target.value)}
                    rows={6}
                    className="rounded-[22px] border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                    placeholder="Describe el objetivo del flujo..."
                  />
                  <button
                    type="button"
                    onClick={applyAiSuggestion}
                    disabled={!settings.integratedAI}
                    className="rounded-2xl bg-[var(--accent)] px-4 py-3 text-sm font-medium text-white disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    Generar pasos con IA
                  </button>
                  <p className="text-sm text-slate-400">La IA sugiere 3–5 pasos claros según contexto, conectores y modo sandbox.</p>
                </div>
              </SectionCard>
            </div>

            <div className="space-y-6">
              <SectionCard
                title={selectedFlow ? selectedFlow.name : "Editor visual"}
                eyebrow="Arrastra la lógica con mínima fricción"
                action={
                  <div className="flex flex-wrap gap-2">
                    <button type="button" onClick={runSandbox} className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-white">
                      Probar sandbox
                    </button>
                    <button type="button" onClick={deploySelectedFlow} className="rounded-full bg-[var(--accent)] px-4 py-2 text-sm font-medium text-white">
                      Desplegar
                    </button>
                    {adminUnlocked ? (
                      <button type="button" onClick={cloneSelectedFlow} className="rounded-full border border-emerald-400/30 bg-emerald-400/10 px-4 py-2 text-sm text-emerald-300">
                        Clonar premium
                      </button>
                    ) : null}
                  </div>
                }
              >
                {selectedFlow ? (
                  <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
                    <div>
                      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                        <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                          <p className="text-xs uppercase tracking-[0.28em] text-slate-400">Estado</p>
                          <p className="mt-2 text-2xl font-semibold text-white">{selectedFlow.status}</p>
                          <p className="mt-1 text-sm text-slate-400">Iteración rápida, deployment one-click.</p>
                        </div>
                        <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                          <p className="text-xs uppercase tracking-[0.28em] text-slate-400">Versión</p>
                          <p className="mt-2 text-2xl font-semibold text-white">v{selectedFlow.version}</p>
                          <p className="mt-1 text-sm text-slate-400">Historial seguro y trazable.</p>
                        </div>
                        <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                          <p className="text-xs uppercase tracking-[0.28em] text-slate-400">Pasos</p>
                          <p className="mt-2 text-2xl font-semibold text-white">{selectedFlow.steps.length}</p>
                          <p className="mt-1 text-sm text-slate-400">Enfoque recomendado 3–5 bloques.</p>
                        </div>
                      </div>

                      <div className="mt-6 grid gap-4">
                        {selectedFlow.steps.map((step, index) => (
                          <StepBadge key={step.id} step={step} last={index === selectedFlow.steps.length - 1} />
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                        <p className="mb-3 text-sm font-medium text-white">Añadir bloque</p>
                        <div className="grid gap-3">
                          <input
                            value={flowStepDraft.title}
                            onChange={(event) => setFlowStepDraft((current) => ({ ...current, title: event.target.value }))}
                            placeholder="Título del bloque"
                            className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                          />
                          <select
                            value={flowStepDraft.connector}
                            onChange={(event) => setFlowStepDraft((current) => ({ ...current, connector: event.target.value }))}
                            className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                          >
                            {CONNECTORS.map((connector) => (
                              <option key={connector[0]} value={connector[0]}>
                                {connector[0]}
                              </option>
                            ))}
                          </select>
                          <select
                            value={flowStepDraft.kind}
                            onChange={(event) => setFlowStepDraft((current) => ({ ...current, kind: event.target.value as FlowKind }))}
                            className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                          >
                            <option value="trigger">Trigger</option>
                            <option value="action">Action</option>
                            <option value="ai">AI</option>
                            <option value="condition">Condition</option>
                            <option value="output">Output</option>
                          </select>
                          <textarea
                            value={flowStepDraft.description}
                            onChange={(event) => setFlowStepDraft((current) => ({ ...current, description: event.target.value }))}
                            rows={4}
                            placeholder="Descripción breve"
                            className="rounded-[22px] border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                          />
                          <button type="button" onClick={addStepToSelectedFlow} className="rounded-2xl bg-[var(--accent)] px-4 py-3 text-sm font-medium text-white">
                            Añadir al flujo
                          </button>
                        </div>
                      </div>

                      <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                        <p className="mb-3 text-sm font-medium text-white">Historial</p>
                        <div className="grid gap-2">
                          {selectedFlow.versions.slice(0, 6).map((version, index) => (
                            <div key={`${version.at}-${index}`} className="rounded-2xl border border-white/10 bg-slate-950/80 px-3 py-2 text-sm text-slate-300">
                              <strong>v{version.version}</strong> — {version.label}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-slate-400">Selecciona un flow o crea uno nuevo.</p>
                )}
              </SectionCard>
            </div>
          </div>
        ) : null}

        {activeTab === "connectors" ? (
          <SectionCard title="Conectores universales" eyebrow="Set inicial extendido">
            <div className="mb-5 grid gap-3 sm:grid-cols-[1fr_200px]">
              <input
                value={connectorQuery}
                onChange={(event) => setConnectorQuery(event.target.value)}
                placeholder="Buscar por nombre, categoría o uso..."
                className="rounded-[22px] border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
              />
              <div className="rounded-[22px] border border-white/10 bg-black/20 px-4 py-3 text-sm text-slate-300">
                {filteredConnectors.length} conectores disponibles
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {filteredConnectors.map((connector) => (
                <div key={connector[0]} className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-semibold text-white">{connector[0]}</p>
                      <p className="mt-1 text-sm text-slate-400">{connector[2]}</p>
                    </div>
                    <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[10px] uppercase tracking-[0.28em] text-slate-300">
                      {connector[1]}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveTab("flows");
                      setFlowStepDraft((current) => ({ ...current, connector: connector[0] }));
                    }}
                    className="mt-4 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-white"
                  >
                    Usar en editor
                  </button>
                </div>
              ))}
            </div>
          </SectionCard>
        ) : null}

        {activeTab === "notes" ? (
          <div className="grid gap-6 xl:grid-cols-[280px_1fr]">
            <SectionCard title="Carpetas" eyebrow="Categorías rápidas">
              <div className="grid gap-3">
                {folders.map((folder) => (
                  <button
                    key={folder.id}
                    type="button"
                    onClick={() => setSelectedFolderId(folder.id)}
                    className={cn(
                      "flex items-center justify-between rounded-[22px] border px-4 py-3 text-left transition",
                      selectedFolderId === folder.id ? "border-transparent bg-white text-slate-950" : "border-white/10 bg-black/20 text-white",
                    )}
                  >
                    <span>{folder.name}</span>
                    <span className="h-3 w-3 rounded-full" style={{ backgroundColor: folder.color }} />
                  </button>
                ))}
                <div className="mt-2 grid gap-3 rounded-[24px] border border-white/10 bg-black/20 p-4">
                  <input
                    value={folderDraft.name}
                    onChange={(event) => setFolderDraft((current) => ({ ...current, name: event.target.value }))}
                    placeholder="Nueva carpeta"
                    className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                  />
                  <input
                    type="color"
                    value={folderDraft.color}
                    onChange={(event) => setFolderDraft((current) => ({ ...current, color: event.target.value }))}
                    className="h-12 w-full rounded-2xl border border-white/10 bg-black/30 p-2"
                  />
                  <button type="button" onClick={addFolder} className="rounded-2xl bg-[var(--accent)] px-4 py-3 text-sm font-medium text-white">
                    Crear carpeta
                  </button>
                </div>
              </div>
            </SectionCard>

            <SectionCard title={`Notas en ${currentFolder?.name ?? "carpeta"}`} eyebrow="Workspace de ideas">
              <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
                <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                  <div className="grid gap-3">
                    <input
                      value={noteDraft.title}
                      onChange={(event) => setNoteDraft((current) => ({ ...current, title: event.target.value }))}
                      placeholder="Título de nota"
                      className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                    />
                    <textarea
                      value={noteDraft.content}
                      onChange={(event) => setNoteDraft((current) => ({ ...current, content: event.target.value }))}
                      rows={8}
                      placeholder="Escribe aquí..."
                      className="rounded-[22px] border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                    />
                    <button type="button" onClick={addNote} className="rounded-2xl bg-[var(--accent)] px-4 py-3 text-sm font-medium text-white">
                      Crear nota
                    </button>
                  </div>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  {currentNotes.map((note) => (
                    <div key={note.id} className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                      <p className="font-semibold text-white">{note.title}</p>
                      <p className="mt-2 whitespace-pre-wrap text-sm text-slate-400">{note.content}</p>
                      <p className="mt-4 text-xs uppercase tracking-[0.28em] text-slate-500">{new Date(note.updatedAt).toLocaleString()}</p>
                    </div>
                  ))}
                </div>
              </div>
            </SectionCard>
          </div>
        ) : null}

        {activeTab === "vicogate" ? (
          <div className="grid gap-6 xl:grid-cols-[340px_1fr]">
            <div className="space-y-6">
              <SectionCard title="Biblioteca VICOgate" eyebrow="PWAs, URLs y uploads">
                <div className="grid gap-3">
                  {visibleGateApps.map((app) => (
                    <button
                      key={app.id}
                      type="button"
                      onClick={() => setSelectedGateAppId(app.id)}
                      className={cn(
                        "rounded-[24px] border p-4 text-left transition",
                        selectedGateAppId === app.id ? "border-transparent bg-white text-slate-950" : "border-white/10 bg-black/20 text-white",
                      )}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="font-semibold">{app.name}</p>
                          <p className={cn("mt-1 text-sm", selectedGateAppId === app.id ? "text-slate-600" : "text-slate-400")}>{app.description}</p>
                        </div>
                        <span className="rounded-full border border-black/10 bg-black/5 px-2 py-1 text-[10px] uppercase tracking-[0.28em]">{app.type}</span>
                      </div>
                    </button>
                  ))}
                  {!adminUnlocked ? (
                    <div className="rounded-[24px] border border-dashed border-amber-400/30 bg-amber-400/10 p-4 text-sm text-amber-200">
                      Las tarjetas admin por URL solo se muestran al desbloquear modo admin.
                    </div>
                  ) : null}
                </div>
              </SectionCard>

              <SectionCard title="Añadir PWA o módulo" eyebrow="URL / archivo / zip">
                <div className="grid gap-3">
                  <input
                    value={gateDraft.name}
                    onChange={(event) => setGateDraft((current) => ({ ...current, name: event.target.value }))}
                    placeholder="Nombre visible"
                    className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                  />
                  <select
                    value={gateDraft.type}
                    onChange={(event) => setGateDraft((current) => ({ ...current, type: event.target.value as GateApp["type"] }))}
                    className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                  >
                    <option value="url">URL</option>
                    <option value="html">HTML</option>
                    <option value="js">JS</option>
                    <option value="json">JSON</option>
                    <option value="zip">ZIP</option>
                  </select>
                  <input
                    value={gateDraft.url}
                    onChange={(event) => setGateDraft((current) => ({ ...current, url: event.target.value }))}
                    placeholder="https://"
                    className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                  />
                  <textarea
                    value={gateDraft.description}
                    onChange={(event) => setGateDraft((current) => ({ ...current, description: event.target.value }))}
                    rows={4}
                    placeholder="Descripción"
                    className="rounded-[22px] border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                  />
                  <button type="button" onClick={addGateApp} className="rounded-2xl bg-[var(--accent)] px-4 py-3 text-sm font-medium text-white">
                    Añadir por URL
                  </button>
                  <label className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-center text-sm text-slate-300">
                    Subir html / js / json / zip
                    <input type="file" accept=".html,.js,.json,.zip" onChange={handleGateFileUpload} className="hidden" />
                  </label>
                </div>
              </SectionCard>
            </div>

            <div className="space-y-6">
              <SectionCard title="Interfaz VICOgate" eyebrow="Abrir y operar PWAs dentro del entorno">
                <div className="grid gap-4 xl:grid-cols-[1fr_300px]">
                  <div className="rounded-[28px] border border-white/10 bg-black/20 p-3">
                    {selectedGateApp ? (
                      <div className="space-y-3">
                        <div className="flex flex-wrap items-center justify-between gap-3 px-2 pt-2">
                          <div>
                            <p className="text-lg font-semibold text-white">{selectedGateApp.name}</p>
                            <p className="text-sm text-slate-400">{selectedGateApp.description}</p>
                          </div>
                          {selectedGateApp.url ? (
                            <a href={selectedGateApp.url} target="_blank" rel="noreferrer" className="rounded-full bg-[var(--accent)] px-4 py-2 text-sm font-medium text-white">
                              Abrir externo
                            </a>
                          ) : null}
                        </div>
                        {selectedGateApp.url ? (
                          <iframe
                            title={selectedGateApp.name}
                            src={selectedGateApp.url}
                            className="h-[560px] w-full rounded-[24px] border border-white/10 bg-slate-950"
                          />
                        ) : selectedGateApp.srcDoc ? (
                          <iframe
                            title={selectedGateApp.name}
                            srcDoc={selectedGateApp.srcDoc}
                            className="h-[560px] w-full rounded-[24px] border border-white/10 bg-slate-950"
                          />
                        ) : (
                          <div className="grid h-[560px] place-items-center rounded-[24px] border border-dashed border-white/10 bg-slate-950 text-center text-sm text-slate-400">
                            Este recurso no ofrece preview embebido. Conserva la tarjeta como activo de biblioteca o ábrelo externamente.
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="grid h-[560px] place-items-center rounded-[24px] border border-dashed border-white/10 bg-slate-950 text-sm text-slate-400">
                        Selecciona una PWA o módulo desde la biblioteca.
                      </div>
                    )}
                  </div>

                  <div className="space-y-4">
                    <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                      <button
                        type="button"
                        onClick={() => setGateChatOpen((current) => !current)}
                        className="flex w-full items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-left"
                      >
                        <span className="font-medium text-white">Chat IA especializado</span>
                        <span className="text-slate-400">{gateChatOpen ? "Ocultar" : "Mostrar"}</span>
                      </button>
                    </div>

                    {gateChatOpen ? (
                      <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                        <div className="max-h-[420px] space-y-3 overflow-auto pr-1">
                          {gateMessages.map((message) => (
                            <div
                              key={message.id}
                              className={cn(
                                "rounded-[22px] px-4 py-3 text-sm",
                                message.role === "assistant" ? "bg-slate-950 text-slate-200" : "bg-[var(--accent)] text-white",
                              )}
                            >
                              {message.content}
                            </div>
                          ))}
                        </div>
                        <div className="mt-4 grid gap-3">
                          <textarea
                            value={gatePrompt}
                            onChange={(event) => setGatePrompt(event.target.value)}
                            rows={4}
                            placeholder="Pregunta sobre biblioteca, embeds, permisos o sandbox..."
                            className="rounded-[22px] border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                          />
                          <button type="button" onClick={sendGatePrompt} className="rounded-2xl bg-[var(--accent)] px-4 py-3 text-sm font-medium text-white">
                            Enviar consulta
                          </button>
                        </div>
                      </div>
                    ) : null}
                  </div>
                </div>
              </SectionCard>
            </div>
          </div>
        ) : null}

        {activeTab === "vicoflow" ? (
          <div className="grid gap-6 xl:grid-cols-[1fr_340px]">
            <SectionCard title="VICO Flow Studio" eyebrow="Widgets, artefactos, plugins y landing pages">
              <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
                <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                  <div className="grid gap-3">
                    <input
                      value={artifactDraft.title}
                      onChange={(event) => setArtifactDraft((current) => ({ ...current, title: event.target.value }))}
                      placeholder="Título del artefacto"
                      className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                    />
                    <textarea
                      value={artifactDraft.prompt}
                      onChange={(event) => setArtifactDraft((current) => ({ ...current, prompt: event.target.value }))}
                      rows={5}
                      placeholder="Describe el artefacto por prompt..."
                      className="rounded-[22px] border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                    />
                    <select
                      value={artifactDraft.type}
                      onChange={(event) =>
                        setArtifactDraft((current) => {
                          const nextType = event.target.value as ArtifactType;
                          return { ...current, type: nextType, code: generateArtifact(current.prompt, nextType) };
                        })
                      }
                      className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                    >
                      <option value="html">HTML</option>
                      <option value="js">JavaScript</option>
                      <option value="json">JSON</option>
                      <option value="react">React</option>
                    </select>
                    <button type="button" onClick={regenerateArtifact} className="rounded-2xl bg-[var(--accent)] px-4 py-3 text-sm font-medium text-white">
                      Generar por prompt
                    </button>
                    <button type="button" onClick={saveArtifact} className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white">
                      Guardar artefacto
                    </button>
                    <button
                      type="button"
                      onClick={() => void copyText(artifactDraft.code)}
                      className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white"
                    >
                      Copiar código
                    </button>
                    <button
                      type="button"
                      onClick={() => downloadFile(`vico-flow-${artifactDraft.type}.${artifactDraft.type === "react" ? "tsx" : artifactDraft.type}`, artifactDraft.code, "text/plain")}
                      className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white"
                    >
                      Descargar archivo
                    </button>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                    <div className="mb-3 flex items-center justify-between gap-3">
                      <p className="font-medium text-white">Editor manual</p>
                      <span className="rounded-full border border-white/10 px-3 py-1 text-[10px] uppercase tracking-[0.28em] text-slate-400">
                        sandbox {settings.sandboxMode ? "on" : "off"}
                      </span>
                    </div>
                    <textarea
                      value={artifactDraft.code}
                      onChange={(event) => setArtifactDraft((current) => ({ ...current, code: event.target.value }))}
                      rows={16}
                      className="w-full rounded-[22px] border border-white/10 bg-slate-950 px-4 py-3 font-mono text-sm text-slate-200 outline-none"
                    />
                  </div>

                  <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                    <div className="mb-3 flex items-center justify-between gap-3">
                      <p className="font-medium text-white">Sandbox preview</p>
                      <span className="text-sm text-slate-400">HTML interactivo · otros formatos en vista de código</span>
                    </div>
                    {settings.sandboxMode && artifactDraft.type === "html" ? (
                      <iframe title="VICO Flow preview" srcDoc={artifactDraft.code} className="h-[420px] w-full rounded-[22px] border border-white/10 bg-slate-950" />
                    ) : (
                      <pre className="overflow-auto whitespace-pre-wrap rounded-[22px] border border-white/10 bg-slate-950 p-4 text-sm text-slate-300">
                        {artifactDraft.code}
                      </pre>
                    )}
                  </div>
                </div>
              </div>
            </SectionCard>

            <SectionCard title="Biblioteca de artefactos" eyebrow="Reusable outputs">
              <div className="grid gap-4">
                {artifacts.map((artifact) => (
                  <div key={artifact.id} className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="font-semibold text-white">{artifact.title}</p>
                        <p className="mt-1 text-sm text-slate-400">{artifact.prompt}</p>
                      </div>
                      <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[10px] uppercase tracking-[0.28em] text-slate-300">{artifact.type}</span>
                    </div>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => setArtifactDraft({ title: artifact.title, prompt: artifact.prompt, type: artifact.type, code: artifact.code })}
                        className="rounded-full bg-[var(--accent)] px-4 py-2 text-sm font-medium text-white"
                      >
                        Abrir
                      </button>
                      <button
                        type="button"
                        onClick={() => void copyText(artifact.code)}
                        className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-white"
                      >
                        Copiar
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </SectionCard>
          </div>
        ) : null}

        {activeTab === "news" ? (
          <div className="grid gap-6 xl:grid-cols-[1fr_320px]">
            <SectionCard title="RSS Noticias IA" eyebrow="EN / ES + visual Google News">
              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                {visibleSources.map((source) => (
                  <div key={source.id} className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="font-semibold text-white">{source.name}</p>
                        <p className="mt-1 text-sm text-slate-400">{source.category}</p>
                      </div>
                      <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[10px] uppercase tracking-[0.28em] text-slate-300">{source.lang}</span>
                    </div>
                    <div className="mt-4 grid gap-2">
                      {source.headlines.map((headline) => (
                        <a
                          key={headline}
                          href={source.url}
                          target="_blank"
                          rel="noreferrer"
                          className="rounded-2xl border border-white/10 bg-slate-950/80 px-3 py-2 text-sm text-slate-300 transition hover:border-white/20 hover:text-white"
                        >
                          {headline}
                        </a>
                      ))}
                    </div>
                    <div className="mt-4 rounded-2xl border border-white/10 bg-white/5 p-3 text-sm text-slate-400">{summarizeSource(source)}</div>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <button type="button" onClick={() => editSource(source)} className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-sm text-white">
                        Editar
                      </button>
                      <button type="button" onClick={() => removeSource(source.id)} className="rounded-full border border-rose-400/30 bg-rose-400/10 px-3 py-1.5 text-sm text-rose-200">
                        Borrar
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </SectionCard>

            <SectionCard title="Gestión de fuentes" eyebrow="Activa, añade y curar">
              <div className="grid gap-4">
                <ToggleRow
                  label="Ticker dinámico top nav"
                  hint="Velocidad super lenta ajustable y activación global del lector RSS."
                  checked={settings.rssEnabled}
                  onChange={(value) => updateSettings("rssEnabled", value)}
                />
                <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                  <label className="mb-2 block text-sm font-medium text-white">Velocidad ticker</label>
                  <input
                    type="range"
                    min={10}
                    max={46}
                    value={settings.tickerSpeed}
                    onChange={(event) => updateSettings("tickerSpeed", Number(event.target.value))}
                    className="w-full accent-[var(--accent)]"
                  />
                </div>
                <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                  <div className="grid gap-3">
                    <input
                      value={sourceDraft.name}
                      onChange={(event) => setSourceDraft((current) => ({ ...current, name: event.target.value }))}
                      placeholder="Nombre de la fuente"
                      className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <select
                        value={sourceDraft.lang}
                        onChange={(event) => setSourceDraft((current) => ({ ...current, lang: event.target.value as SourceLang }))}
                        className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                      >
                        <option value="es">ES</option>
                        <option value="en">EN</option>
                      </select>
                      <input
                        value={sourceDraft.category}
                        onChange={(event) => setSourceDraft((current) => ({ ...current, category: event.target.value }))}
                        placeholder="Categoría"
                        className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                      />
                    </div>
                    <input
                      value={sourceDraft.url}
                      onChange={(event) => setSourceDraft((current) => ({ ...current, url: event.target.value }))}
                      placeholder="https://"
                      className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                    />
                    <textarea
                      value={sourceDraft.headline}
                      onChange={(event) => setSourceDraft((current) => ({ ...current, headline: event.target.value }))}
                      rows={4}
                      placeholder="Headline o nota destacada"
                      className="rounded-[22px] border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                    />
                    <button type="button" onClick={saveSource} className="rounded-2xl bg-[var(--accent)] px-4 py-3 text-sm font-medium text-white">
                      {editingSourceId ? "Guardar cambios" : "Añadir fuente"}
                    </button>
                  </div>
                </div>
              </div>
            </SectionCard>
          </div>
        ) : null}

        {activeTab === "settings" ? (
          <div className="grid gap-6 xl:grid-cols-[1fr_360px]">
            <SectionCard title="Configuración avanzada" eyebrow="10 opciones funcionales + admin">
              <div className="grid gap-4 md:grid-cols-2">
                <ToggleRow
                  label="1. IA integrada"
                  hint="Activa sugerencias contextuales y generación intermedia de pasos."
                  checked={settings.integratedAI}
                  onChange={(value) => updateSettings("integratedAI", value)}
                />
                <div className="rounded-[22px] border border-white/10 bg-black/20 p-4">
                  <p className="font-medium text-white">2. Velocidad de animaciones</p>
                  <p className="mt-1 text-sm text-slate-400">Controla transiciones y ritmo visual del dashboard.</p>
                  <input
                    type="range"
                    min={0.6}
                    max={1.8}
                    step={0.1}
                    value={settings.animationSpeed}
                    onChange={(event) => updateSettings("animationSpeed", Number(event.target.value))}
                    className="mt-4 w-full accent-[var(--accent)]"
                  />
                </div>
                <div className="rounded-[22px] border border-white/10 bg-black/20 p-4">
                  <p className="font-medium text-white">3. Colores de interfaz</p>
                  <div className="mt-3 grid gap-3 sm:grid-cols-2">
                    <select
                      value={settings.brandTheme}
                      onChange={(event) => updateSettings("brandTheme", event.target.value as BrandTheme)}
                      className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                    >
                      <option value="electric">Gradiente Azul Eléctrico</option>
                      <option value="gold">Gradiente Dorado</option>
                    </select>
                    <input
                      type="color"
                      value={settings.customAccent}
                      onChange={(event) => updateSettings("customAccent", event.target.value)}
                      className="h-12 w-full rounded-2xl border border-white/10 bg-black/30 p-2"
                    />
                  </div>
                </div>
                <div className="rounded-[22px] border border-white/10 bg-black/20 p-4">
                  <p className="font-medium text-white">4. Exportar / importar flows</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <button type="button" onClick={exportFlows} className="rounded-full bg-[var(--accent)] px-4 py-2 text-sm font-medium text-white">
                      Exportar JSON
                    </button>
                    <label className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-white">
                      Importar JSON
                      <input type="file" accept=".json" onChange={handleImportFlows} className="hidden" />
                    </label>
                  </div>
                </div>
                <ToggleRow
                  label="5. Modo offline-first"
                  hint="Prioriza persistencia local y experiencia híbrida dispositivo / nube."
                  checked={settings.offlineFirst}
                  onChange={(value) => updateSettings("offlineFirst", value)}
                />
                <ToggleRow
                  label="6. Editor de scripts para widgets"
                  hint="Permite crear bloques de dashboard que se guardan automáticamente."
                  checked={settings.scriptEditorEnabled}
                  onChange={(value) => updateSettings("scriptEditorEnabled", value)}
                />
                <div className="rounded-[22px] border border-white/10 bg-black/20 p-4">
                  <p className="font-medium text-white">7. Lector RSS IA</p>
                  <div className="mt-3 grid gap-3 sm:grid-cols-2">
                    <select
                      value={settings.rssLanguage}
                      onChange={(event) => updateSettings("rssLanguage", event.target.value as Settings["rssLanguage"])}
                      className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                    >
                      <option value="both">EN + ES</option>
                      <option value="en">Solo EN</option>
                      <option value="es">Solo ES</option>
                    </select>
                    <select
                      value={settings.rssView}
                      onChange={(event) => updateSettings("rssView", event.target.value as Settings["rssView"])}
                      className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                    >
                      <option value="ticker">Ticker dinámico</option>
                      <option value="cards">Google News cards</option>
                    </select>
                  </div>
                </div>
                <div className="rounded-[22px] border border-white/10 bg-black/20 p-4">
                  <p className="font-medium text-white">8. Accesos directos nav bar</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {TAB_ITEMS.filter((tab) => !["overview", "settings", "legal"].includes(tab.id)).map((tab) => {
                      const active = settings.navbarShortcuts.includes(tab.id);
                      return (
                        <button
                          key={tab.id}
                          type="button"
                          onClick={() =>
                            updateSettings(
                              "navbarShortcuts",
                              active
                                ? settings.navbarShortcuts.filter((item) => item !== tab.id)
                                : [...settings.navbarShortcuts, tab.id],
                            )
                          }
                          className={cn(
                            "rounded-full border px-3 py-1.5 text-sm transition",
                            active ? "border-transparent bg-[var(--accent)] text-white" : "border-white/10 bg-white/5 text-slate-300",
                          )}
                        >
                          {tab.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
                <ToggleRow
                  label="9. Modo sandbox"
                  hint="Activa previews controladas para flows, widgets y artefactos."
                  checked={settings.sandboxMode}
                  onChange={(value) => updateSettings("sandboxMode", value)}
                />
                <div className="rounded-[22px] border border-white/10 bg-black/20 p-4">
                  <p className="font-medium text-white">10. Seguridad avanzada</p>
                  <div className="mt-3 grid gap-3">
                    <select
                      value={settings.securityProfile}
                      onChange={(event) => updateSettings("securityProfile", event.target.value as Settings["securityProfile"])}
                      className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                    >
                      <option value="balanced">Balanced</option>
                      <option value="strict">Strict</option>
                      <option value="enterprise">Enterprise</option>
                    </select>
                    <ToggleRow
                      label="Hashes avanzados"
                      hint="Muestra e importa llave maestra JSON con perfil premium."
                      checked={settings.advancedHashes}
                      onChange={(value) => updateSettings("advancedHashes", value)}
                    />
                    <ToggleRow
                      label="Sonidos opcionales"
                      hint="Feedback sonoro mínimo para acciones clave de UI."
                      checked={settings.soundEnabled}
                      onChange={(value) => updateSettings("soundEnabled", value)}
                    />
                  </div>
                </div>
              </div>
            </SectionCard>

            <SectionCard title="Modo Admin" eyebrow="Llave maestra y premium">
              <div className="grid gap-4">
                <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                  <p className="font-medium text-white">Hash master key</p>
                  <p className="mt-1 text-sm text-slate-400">Formato JSON descargable/subible • esquema SHA-246 con motor SHA-256 real.</p>
                  <p className="mt-3 rounded-2xl border border-white/10 bg-slate-950 px-3 py-2 font-mono text-xs text-slate-300 break-all">
                    {uploadedAdminKey?.hash || baseAdminHash || "Generando hash..."}
                  </p>
                </div>
                <input
                  type="password"
                  value={adminPassword}
                  onChange={(event) => setAdminPassword(event.target.value)}
                  placeholder="Contraseña admin"
                  className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none"
                />
                <button type="button" onClick={() => void unlockAdmin()} className="rounded-2xl bg-[var(--accent)] px-4 py-3 text-sm font-medium text-white">
                  Desbloquear premium
                </button>
                <div className="flex flex-wrap gap-2">
                  <button type="button" onClick={() => void exportAdminKey()} className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-white">
                    Descargar llave JSON
                  </button>
                  <label className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-white">
                    Subir llave JSON
                    <input type="file" accept=".json" onChange={handleImportAdminKey} className="hidden" />
                  </label>
                  {adminUnlocked ? (
                    <button type="button" onClick={exportPwaSpec} className="rounded-full border border-emerald-400/30 bg-emerald-400/10 px-4 py-2 text-sm text-emerald-300">
                      Exportar APK/PWA spec
                    </button>
                  ) : null}
                </div>
                <div className={cn("rounded-[24px] border p-4 text-sm", adminUnlocked ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-200" : "border-white/10 bg-black/20 text-slate-300")}>
                  {adminFeedback}
                </div>
                <div className="grid gap-3">
                  <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                    <p className="font-medium text-white">Premium 1 — Editor visual avanzado</p>
                    <p className="mt-1 text-sm text-slate-400">Clonación profunda y control de versiones extendido.</p>
                  </div>
                  <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                    <p className="font-medium text-white">Premium 2 — Marketplace de módulos</p>
                    <p className="mt-1 text-sm text-slate-400">Catálogo interno para bundles premium y monetización.</p>
                  </div>
                  <div className="rounded-[24px] border border-white/10 bg-black/20 p-4">
                    <p className="font-medium text-white">Premium 3 — Exportación directa</p>
                    <p className="mt-1 text-sm text-slate-400">Perfil de distribución para app stores y despliegue como PWA.</p>
                  </div>
                </div>
              </div>
            </SectionCard>
          </div>
        ) : null}

        {activeTab === "legal" ? (
          <div className="grid gap-6 xl:grid-cols-[1fr_320px]">
            <SectionCard title="Avisos legales y política de privacidad" eyebrow="Store ready">
              <div className="space-y-5 text-sm leading-7 text-slate-300">
                <p>
                  VICO Tékton es una plataforma modular de automatización con funciones de diseño visual, organización de contenidos, lectura de fuentes informativas, biblioteca de módulos y experimentación sandbox. El usuario conserva el control sobre los datos que introduzca localmente en este dispositivo.
                </p>
                <p>
                  Privacidad: esta demo prioriza persistencia local en el navegador para notas, flows, widgets, ajustes y bibliotecas cargadas por el usuario. No se transmite información a servidores propios desde esta interfaz estática. Cualquier integración futura con APIs externas deberá configurarse con consentimiento explícito, credenciales seguras y permisos mínimos necesarios.
                </p>
                <p>
                  Compartición y monetización: la plataforma está preparada conceptualmente para publicar módulos premium, bundles y perfiles de exportación PWA/APK. Antes de distribuir en Google Play Store o App Store, se recomienda añadir políticas de tratamiento de datos, consentimiento, soporte al usuario y revisión de conectores de terceros.
                </p>
                <p>
                  Responsabilidad: el usuario es responsable de revisar scripts, widgets, URLs, archivos y automatizaciones antes de activarlos en entornos reales. Las cargas locales y previews sandbox se ofrecen como herramienta de experimentación y validación previa.
                </p>
              </div>
            </SectionCard>

            <SectionCard title="Créditos" eyebrow="Autoría y enlaces">
              <div className="space-y-4 text-sm text-slate-300">
                <p className="font-medium text-white">© 2026 VICO Tékton App. Todos los derechos reservados.</p>
                <p>Creado por Jaime Andrés Dueñas Vicuña</p>
                <a
                  href="https://www.linkedin.com/in/jaime-andrés-dueñas-vicuña"
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-3 rounded-[22px] border border-white/10 bg-black/20 px-4 py-3 text-white"
                >
                  <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current">
                    <path d="M4.98 3.5C4.98 4.88 3.87 6 2.49 6S0 4.88 0 3.5 1.11 1 2.49 1s2.49 1.12 2.49 2.5zM.5 8h4V23h-4V8zm7 0h3.84v2.05h.05c.53-1.01 1.84-2.05 3.79-2.05C19.2 8 20 10.12 20 13.07V23h-4v-8.11c0-1.94-.03-4.43-2.7-4.43-2.7 0-3.11 2.1-3.11 4.29V23h-4V8z" />
                  </svg>
                  LinkedIn
                </a>
                <a
                  href="https://www.paypal.com/paypalme/texiduvi"
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-[22px] border border-white/10 bg-black/20 px-4 py-3 text-white"
                >
                  PayPal
                </a>
              </div>
            </SectionCard>
          </div>
        ) : null}
      </main>
    </div>
  );
}
